from mrjob.job import MRJob
import time

class Part_D_Fork(MRJob):

#define the mapper.
	def mapper(self, _,line):

		#The transactions data is split by create a fields line that splits the data by ','.'
		fields = line.split(',')
		try:

			if len(fields) == 9:
				miner = fields[2]
				block = fields[0]
				unix_timestamp = int(fields[7])
				date =  time.gmtime(unix_timestamp)
				timestamp = time.strftime("%d/%m/%y", date) # convert the data to day, time, month year hour and seconds.
				yield (block, (timestamp,miner))
		except:
			pass

	def reducer(self,key,value):
		miner_list = []
		for m in value:
			miner_list.append(m)
		if len(miner_list) > 1:
			yield ('Date',(m[0]))

if __name__=='__main__':
    Part_D_Fork.run()
